CMPT 135 Assignment 5
=====================

Names of Team Members
---------------------

(include the full names, SFU email addresses, and SFU student numbers of all
team members)
Name : Min Woo (Andy) Kim
St.# : 301448177
Email: andy_kim_10@sfu.ca


Instructions for Compiling and Running
--------------------------------------

(put instructions here for compiling and running your program; hopefully it's
just to type "make" in the shell!)

*if there is a clock skew warning when typed "make", then type "make clean" first. This isn't a compilation error, it just does that sometimes.* 

1. Type "make"
2. Then type "./a5_main"

Then the program should run


Limitations
-----------

Once the program enters a cycle of adding a record for example, it cannot go back to main menu until 
all requested values has been inputted. 

The arrow keys are not programmmed to work as intended

The terminal does not have infinite size so if something goes out of bounds, it won't print

The 
Known Bugs
----------

(list all known bugs here)

sometimes, the prompt when the user inputs an incorrect value
may or may not appear in unwanted places


Extra Features
--------------

(if your program has any extra or special features, tell us about them here)

For implementation of two different kinds of search for string and int fields, 
my program asks the user which kind of search they want. 

all string inputs are case insensitive. 
*NOTE: the instructions say that we must find a string that exactly matches what the uesr typed. However, I've asked TA Yinglai Wang 
about this instructions and he stated that it was acceptable for all string inputs to be case insensitive.*

the delete button works when entering a string input

In the main and field menu, the selection that the uesr chooses is highlighted.








